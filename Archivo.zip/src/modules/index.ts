export * from './muscles/controllers'
export * from './equipments/controllers'
export * from './bodyparts/controllers'
export * from './exercises/controllers'
