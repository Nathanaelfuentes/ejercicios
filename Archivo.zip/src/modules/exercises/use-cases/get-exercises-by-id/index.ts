export * from './get-exercise-by-id.usecase'
