import { z } from 'zod'
export const MuscleModel = z.object({
  name: z.string()
})
