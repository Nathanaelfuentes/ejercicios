export * from './get-bodypart.usecase'
