export * from './bodyPart.controller'
