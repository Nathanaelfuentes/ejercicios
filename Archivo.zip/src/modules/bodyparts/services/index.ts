export * from './body-part.service'
