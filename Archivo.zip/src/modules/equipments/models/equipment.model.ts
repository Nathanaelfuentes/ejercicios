import { z } from 'zod'
export const EquipmentModel = z.object({
  name: z.string()
})
